# Changelog

## [1.0.2] - 27/11/2024

- Updated dependencies

## [1.0.1] - 29/12/2023

- Updated dependencies

## [1.0.0]

Initial production release
