import React, { Component } from "react";
import BlogsListTable from "components/admin/CRUD/Blogs/list/BlogsListTable";

class BlogsListPage extends Component {
  render() {
    return (
      <div>
        <BlogsListTable />
      </div>
    );
  }
}

export default BlogsListPage;
